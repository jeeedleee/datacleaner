# datacleaner

基于大语言模型的 RStudio 数据清洗代码生成插件

## 简介

datacleaner 是一个 RStudio Addin，它利用大语言模型（LLM）的能力，帮助用户快速生成数据清洗代码。用户只需：

1. 导入数据文件（支持 CSV 和 Excel）
2. 在可视化界面中查看数据
3. 为每列指定清洗规则（用自然语言描述）
4. 点击生成，AI 自动生成 R 代码
5. 代码直接插入到 RStudio 编辑器

## 功能特点

- **可视化数据预览**：使用 DT 表格展示数据，支持排序、筛选
- **灵活的数据导入**：支持 CSV 和 Excel 文件
- **自然语言描述**：用中文或英文描述清洗需求
- **智能代码生成**：基于 LLM 生成符合 tidyverse 风格的 R 代码
- **无缝集成**：生成的代码直接插入 RStudio 编辑器
- **配置简单**：只需配置 API 密钥和模型名称

## 安装

### 前置要求

- R >= 3.5.0
- RStudio IDE

### 方法一：从 Gitee 安装（推荐国内用户）

```r
# 安装 devtools（如果尚未安装）
install.packages("devtools")

# 从 Gitee 安装
devtools::install_git("https://gitee.com/your-username/datacleaner")
```

### 方法二：从 GitHub 安装

```r
devtools::install_github("your-username/datacleaner")
```

### 方法三：从源码包安装

下载 `datacleaner_0.1.0.tar.gz` 后：

```r
install.packages("datacleaner_0.1.0.tar.gz", repos = NULL, type = "source")
```

### 方法四：从二进制包安装（仅 Windows）

下载 `datacleaner_0.1.0.zip` 后：

```r
install.packages("datacleaner_0.1.0.zip", repos = NULL, type = "win.binary")
```

### 依赖包安装

datacleaner 依赖以下 R 包，安装时会自动安装：

- shiny
- miniUI
- DT
- httr2
- readr
- readxl
- rstudioapi
- jsonlite
- yaml

**国内用户建议配置镜像加速：**

```r
# 配置清华大学 CRAN 镜像
options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
```

## 快速开始

### 1. 配置 API

首次使用需要配置 API 密钥和模型：

1. 在 RStudio 中，点击菜单 **Addins** → **数据清洗助手**
2. 在打开的界面中，点击 **设置** 标签页
3. 填写以下信息：
   - **API 密钥**：你的 API 密钥
   - **模型**：模型名称（如 `gpt-4`、`gpt-3.5-turbo` 等）
4. 点击 **保存设置**

配置会保存在 `~/.datacleaner/config.yml`，下次使用时自动加载。

### 2. 使用流程

**步骤 1：导入数据**

- 点击 **导入数据** 标签页
- 点击 **选择文件** 按钮，选择 CSV 或 Excel 文件
- 数据会自动加载并显示在表格中

**步骤 2：指定清洗规则**

- 在 **清洗规则** 标签页，为需要清洗的列指定规则
- 用自然语言描述，例如：
  - "删除缺失值"
  - "将日期格式统一为 YYYY-MM-DD"
  - "将性别列的'男'/'女'转换为'M'/'F'"

**步骤 3：生成代码**

- 点击 **生成代码** 按钮
- AI 会根据你的规则生成 R 代码
- 生成的代码会自动插入到 RStudio 编辑器的当前光标位置

**步骤 4：运行代码**

- 在 RStudio 编辑器中检查生成的代码
- 根据需要进行调整
- 运行代码完成数据清洗

## 使用示例

假设你有一个包含用户信息的 CSV 文件：

```
姓名,年龄,性别,注册日期
张三,25,男,2023/1/15
李四,,女,2023-02-20
王五,30,M,20230305
```

你可以指定以下清洗规则：

- **年龄列**：填充缺失值为平均值
- **性别列**：统一为 M/F 格式
- **注册日期列**：统一为 YYYY-MM-DD 格式

生成的代码示例：

```r
library(dplyr)
library(lubridate)

data_cleaned <- data %>%
  mutate(
    年龄 = ifelse(is.na(年龄), mean(年龄, na.rm = TRUE), 年龄),
    性别 = case_when(
      性别 == "男" ~ "M",
      性别 == "女" ~ "F",
      TRUE ~ 性别
    ),
    注册日期 = ymd(注册日期)
  )
```

## 常见问题

### Q: 支持哪些数据格式？

A: 目前支持 CSV 和 Excel (.xlsx, .xls) 格式。

### Q: API 密钥如何获取？

A: 本插件使用 https://537-ai.net 服务，请联系服务提供商获取 API 密钥。

### Q: 生成的代码可以修改吗？

A: 可以。生成的代码会插入到 RStudio 编辑器中，你可以根据实际需求进行调整。

### Q: 支持哪些 LLM 模型？

A: 支持所有兼容 OpenAI API 格式的模型，如 GPT-4、GPT-3.5-turbo 等。

### Q: 配置文件保存在哪里？

A: 配置保存在 `~/.datacleaner/config.yml`。

### Q: 如何更新到最新版本？

A: 重新运行安装命令，添加 `force = TRUE` 参数：

```r
devtools::install_git("https://gitee.com/your-username/datacleaner", force = TRUE)
```

## 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 贡献

欢迎提交 Issue 和 Pull Request！

## 联系方式

如有问题或建议，请通过以下方式联系：

- 提交 Issue
- 发送邮件至：jeeedleee14@gmail.com

---

**注意**：本工具生成的代码仅供参考，请在使用前仔细检查和测试。
